import random
import time

while True:
    players = input("Enter # of players(2-4) ")
    if players.isdigit():
        players = int(players)
        if  1< players<=4:
            break
        else:
            print("Enter number 2-4")
    else:
        print("Enter a number")


#Players
player1 = ("Input Player 1: ")
player2 = ("Input Player 2: ")
player3 = ("Input Player 3: ")
player4 = ("Input Player 4: ")

if players == int(2):
    input(player1)
    input(player2)
elif players==int(3):
        input(player1)
        input(player2)
        input(player3)

if players ==4:
         input(str(player1))
         input(str(player2))
         input(str(player3))
         input(str(player4))

#Cards in Hand
def hand_value():
    min_hand = 0
    max_value = 21










print("Starting Game")
time.sleep(3)
# Game
def roll():
    min_card = 1
    max_card = 11
    roll = random.randint(min_card , max_card)
    return roll
value = roll()
max_value = 21
players_value = " "
starting_value = 0
var = int(players_value) == roll()
while players_value < max_value :
    print("Player 1 Value is " + int(players_value))
    hit = value + roll()
    Hit_card = input("Do you want to hit?Y/N")
    if Hit_card.upper() == 'N':
        print("Turn Ended")
    else:
         print(int(players_value) +  roll)
    if players_value > 21:
        print("Loser")
    break
